package com.example.group2_comp304lab4.util

object Constants {
    const val DB_NAME = "center_database"
}
