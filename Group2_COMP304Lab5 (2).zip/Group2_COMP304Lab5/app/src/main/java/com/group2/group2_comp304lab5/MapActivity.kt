package com.group2.group2_comp304lab5

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap


    var lat: Double = 0.0
    var lon: Double = 0.0
    var name: String =""
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                // Handle the back button press
                onBackPressed()
                return true
            }
            // Add other menu items handling if needed
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map)


        lat = intent.getDoubleExtra("lat",0.0)
        lon = intent.getDoubleExtra("lon",0.0)

        Log.i("nychollas","Lat: ${lat.toString()}, lon: ${lon.toString()}")
        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    override fun onMapReady(gMap: GoogleMap) {
        googleMap = gMap
        val icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)

        // Replace these coordinates with the ones you want to display on the map
        val location = LatLng(lat, lon)
        val marker = googleMap.addMarker(
            MarkerOptions()
                .position(location)
                .title(name)
                .icon(icon)
        )
        // Move the camera to the specified coordinates
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(location))
        googleMap.animateCamera(CameraUpdateFactory.zoomTo(15f))
        val btChangeView = findViewById<ImageButton>(R.id.btChangeView)
        btChangeView.setOnClickListener() {
            // Toggle between normal and satellite views
            if (googleMap.mapType == GoogleMap.MAP_TYPE_NORMAL) {
                googleMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                btChangeView.setImageResource(R.drawable.baseline_map_24 )
            } else {
                googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                btChangeView.setImageResource(R.drawable.baseline_satellite_alt_24)
            }


        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

}