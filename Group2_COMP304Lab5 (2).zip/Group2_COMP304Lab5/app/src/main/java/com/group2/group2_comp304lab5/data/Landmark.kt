package com.group2.group2_comp304lab5.data

import android.content.Context
import android.util.Log
import com.group2.group2_comp304lab5.R
import org.xmlpull.v1.XmlPullParser

data class Landmark(
    val name: String,
    val type: String,
    val address: String,
    val latitude: Double,
    val longitude: Double
)

// Function to parse the XML resource and create a list of Landmark objects
fun parseLandmarks(context: Context,type: String): List<Landmark> {
    val landmarksArray = context.resources.getStringArray(R.array.landmark_list)
    val landmarksList = mutableListOf<Landmark>()

    for (landmarkData in landmarksArray) {
        Log.i("nychollas", landmarkData.split(";")[3])
        val parts = landmarkData.split(";")
        val landmark = Landmark(
            name = parts[0],
            type = parts[1],
            address = parts[2],
            latitude = parts[3].toDouble(),
            longitude = parts[4].toDouble()
        )

        Log.i("nychollas", "landmark.type ${landmark.type}, $type")
        if(landmark.type == type){

            Log.i("nychollas", "entrou no if")
            landmarksList.add(landmark)
        }
    }

    return landmarksList
}

fun parseTypes(context: Context): List<String>{
    val landmarksArray = context.resources.getStringArray(R.array.landmark_list)
    val landmarksList = mutableListOf<Landmark>()
    var typesRet: MutableList<String>? = null
    typesRet = mutableListOf()
    for (landmarkData in landmarksArray) {
        val parts = landmarkData.split(";")
        typesRet?.add(parts[1])
    }

    return typesRet.distinct()

}