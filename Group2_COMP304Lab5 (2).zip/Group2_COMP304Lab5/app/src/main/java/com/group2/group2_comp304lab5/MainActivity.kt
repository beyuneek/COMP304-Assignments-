package com.group2.group2_comp304lab5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.group2.group2_comp304lab5.data.Landmark
import com.group2.group2_comp304lab5.data.LandmarkAdapter
import com.group2.group2_comp304lab5.data.TypesAdapter
import com.group2.group2_comp304lab5.data.parseLandmarks
import com.group2.group2_comp304lab5.data.parseTypes


class MainActivity : AppCompatActivity() {
    private var viewType = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            val typeList: List<String> = parseTypes(this)

            val customAdapter = TypesAdapter(typeList)

            val recyclerView: RecyclerView = findViewById(R.id.recycler_view)

            recyclerView.adapter = customAdapter

            val layoutManager = LinearLayoutManager(this)
            recyclerView.layoutManager = layoutManager

    }
}
