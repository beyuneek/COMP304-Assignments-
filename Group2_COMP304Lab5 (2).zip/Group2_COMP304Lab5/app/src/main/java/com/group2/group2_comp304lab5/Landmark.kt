package com.group2.group2_comp304lab5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.group2.group2_comp304lab5.data.Landmark
import com.group2.group2_comp304lab5.data.LandmarkAdapter
import com.group2.group2_comp304lab5.data.TypesAdapter
import com.group2.group2_comp304lab5.data.parseLandmarks
import com.group2.group2_comp304lab5.data.parseTypes


class Landmark : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
            val type = intent.getStringExtra("filter").toString()
            val landmarkList: List<Landmark> = parseLandmarks(this,type)

            val customAdapter = LandmarkAdapter(landmarkList)

            val recyclerView: RecyclerView = findViewById(R.id.recycler_view)

            recyclerView.adapter = customAdapter

            val layoutManager = LinearLayoutManager(this)
            recyclerView.layoutManager = layoutManager
        }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                // Handle the back button press
                onBackPressed()
                return true
            }
            // Add other menu items handling if needed
        }
        return super.onOptionsItemSelected(item)
    }
    }
