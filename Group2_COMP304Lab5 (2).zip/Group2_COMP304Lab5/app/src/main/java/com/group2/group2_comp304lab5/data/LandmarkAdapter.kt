package com.group2.group2_comp304lab5.data

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.group2.group2_comp304lab5.MapActivity
import com.group2.group2_comp304lab5.R

class LandmarkAdapter(private val dataSet: List<Landmark>) : RecyclerView.Adapter<LandmarkAdapter.ViewHolder>() {


        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val name: TextView
            val address: TextView
            val type: TextView
            val bt: ImageButton

            init {
                // Define click listener for the ViewHolder's View
                name = view.findViewById(R.id.textViewName)
                address = view.findViewById(R.id.textViewAddress)
                type = view.findViewById(R.id.type)
                bt = view.findViewById(R.id.btType)
            }
        }

        // Create new views (invoked by the layout manager)
        override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
            // Create a new view, which defines the UI of the list item
            val view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.text_row_item, viewGroup, false)
            return ViewHolder(view)
        }

        // Replace the contents of a view (invoked by the layout manager)
        override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

            // Get element from your dataset at this position and replace the
            // contents of the view with that element
            viewHolder.name.text = "Name: ${dataSet[position].name}"
            viewHolder.type.text = "Category: ${dataSet[position].type}"
            viewHolder.address.text = "Address: ${dataSet[position].address}"
            viewHolder.bt.setOnClickListener(){
                val intent = Intent(viewHolder.itemView.context,MapActivity::class.java);
                val lat = dataSet[position].latitude
                val lon = dataSet[position].longitude
                val name = dataSet[position].name


                intent.putExtra("lat",lat.toDouble())
                intent.putExtra("lon",lon.toDouble())
                intent.putExtra("name",name)

                Log.i("nychollas","PUT ==== Lat: ${lat.toString()}, lon: ${lon.toString()}")
                viewHolder.itemView.context.startActivity(intent)
            }
        }

        // Return the size of your dataset (invoked by the layout manager)
        override fun getItemCount() = dataSet.size

}