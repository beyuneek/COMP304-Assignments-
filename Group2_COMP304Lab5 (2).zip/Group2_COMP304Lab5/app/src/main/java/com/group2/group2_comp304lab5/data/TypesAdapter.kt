package com.group2.group2_comp304lab5.data

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.group2.group2_comp304lab5.Landmark
import com.group2.group2_comp304lab5.MainActivity
import com.group2.group2_comp304lab5.MapActivity
import com.group2.group2_comp304lab5.R

class TypesAdapter(private val dataSet: List<String>) : RecyclerView.Adapter<TypesAdapter.ViewHolder>() {


        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val type: TextView
            val bt: ImageButton

            init {
                // Define click listener for the ViewHolder's View
                type = view.findViewById(R.id.type)
                bt = view.findViewById(R.id.btViewDetailType)
            }
        }

        // Create new views (invoked by the layout manager)
        override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ViewHolder {
            // Create a new view, which defines the UI of the list item
            val view = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.activity_types, viewGroup, false)
            return ViewHolder(view)
        }

        // Replace the contents of a view (invoked by the layout manager)
        override fun onBindViewHolder(viewHolder: ViewHolder, position: Int) {

            viewHolder.type.text = "Category: ${dataSet[position]}"
            viewHolder.bt.setOnClickListener(){
                val intent = Intent(viewHolder.itemView.context,Landmark::class.java);
                intent.putExtra("filter", dataSet[position])
                viewHolder.itemView.context.startActivity(intent)
            }
        }

        // Return the size of your dataset (invoked by the layout manager)
        override fun getItemCount() = dataSet.size

}