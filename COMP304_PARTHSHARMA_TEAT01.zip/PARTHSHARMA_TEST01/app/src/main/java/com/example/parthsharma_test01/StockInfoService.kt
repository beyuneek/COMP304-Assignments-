package com.example.parthsharma_test01

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.widget.Toast

@Suppress("DEPRECATION")
class StockInfoService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Safely retrieve the CompanyStock object from the intent
        // Safely retrieve the CompanyStock object from the intent
        val selectedCompanyStock = intent?.getParcelableExtra<CompanyStock>("selectedCompanyStock")

// Check if selectedCompanyStock is not null
        if (selectedCompanyStock != null) {
            // Display the company stock information using Toast
            Toast.makeText(
                this,
                "Company Stock Info received:\nCompany Name: ${selectedCompanyStock.companyName}\nOpening Price: ${selectedCompanyStock.openingPrice}\nClosing Price: ${selectedCompanyStock.closingPrice}",
                Toast.LENGTH_LONG
            ).show()
        }

        return super.onStartCommand(intent, flags, startId)
    }

    override fun onBind(intent: Intent): IBinder? {
        // Implement your code to return the communication channel to the service
        throw UnsupportedOperationException("Not yet implemented")
    }
}
