package com.example.parthsharma_test01

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class StockManager(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "Stocks.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "CompanyStock"
        private const val COMPANY_NAME = "companyName"
        private const val OPENING_PRICE = "openingPrice"
        private const val CLOSING_PRICE = "closingPrice"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableStatement = "CREATE TABLE $TABLE_NAME (" +
                "$COMPANY_NAME TEXT PRIMARY KEY," +
                "$OPENING_PRICE REAL," +
                "$CLOSING_PRICE REAL)"
        db.execSQL(createTableStatement)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    @Throws(Exception::class)
    fun addCompanyStock(companyStock: CompanyStock): Boolean {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COMPANY_NAME, companyStock.companyName)
            put(OPENING_PRICE, companyStock.openingPrice)
            put(CLOSING_PRICE, companyStock.closingPrice)
        }

        val result = db.insert(TABLE_NAME, null, contentValues)
        db.close()
        return result != -1L
    }

    @Throws(Exception::class)
    fun getCompanyStock(companyName: String): Cursor {
        val db = this.readableDatabase
        return db.rawQuery("SELECT * FROM $TABLE_NAME WHERE $COMPANY_NAME = ?", arrayOf(companyName))
    }

    fun dbInitialize(tableName: String, tableCreatorString: String) {
        val db = this.writableDatabase
        db.execSQL("DROP TABLE IF EXISTS $tableName")
        db.execSQL(tableCreatorString)
        db.close()
    }
}
