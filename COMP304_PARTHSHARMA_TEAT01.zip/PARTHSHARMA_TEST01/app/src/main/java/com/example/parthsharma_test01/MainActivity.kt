package com.example.parthsharma_test01

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var stockManager: StockManager? = null

    private var companyNameTextView: TextView? = null
    private var openingPriceTextView: TextView? = null
    private var closingPriceTextView: TextView? = null

    private var btnInsertStocks: Button? = null
    private var btnDisplayStockInfo: Button? = null

    private var companyNameRadioGrp: RadioGroup? = null

    private var selectedCompanyName: String? = null

    companion object {
        const val TABLE_NAME = "CompanyStock"
        const val tableCreatorString: String =
            "CREATE TABLE $TABLE_NAME (companyName TEXT PRIMARY KEY, openingPrice REAL, closingPrice REAL)"
    }

    @SuppressLint("SetTextI18n", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        companyNameTextView = findViewById(R.id.company_name_text_view)
        openingPriceTextView = findViewById(R.id.opening_price_text_view)
        closingPriceTextView = findViewById(R.id.closing_price_text_view)

        btnInsertStocks = findViewById(R.id.insert_stocks_btn)
        btnDisplayStockInfo = findViewById(R.id.display_stock_info_btn)

        companyNameRadioGrp = findViewById(R.id.company_name_radio_grp)

        companyNameTextView?.visibility = View.INVISIBLE
        openingPriceTextView?.visibility = View.INVISIBLE
        closingPriceTextView?.visibility = View.INVISIBLE

        try {
            stockManager = StockManager(this)
            stockManager?.dbInitialize(TABLE_NAME, tableCreatorString)
        } catch (exception: Exception) {
            Toast.makeText(this, exception.message, Toast.LENGTH_SHORT).show()
            exception.message?.let { Log.i("Error: ", it) }
        }

        btnInsertStocks?.setOnClickListener {
            insertCompanyStocks()
        }

        companyNameRadioGrp?.setOnCheckedChangeListener { _, checkedId ->
            handleRadioGroupChanges(checkedId)
        }

        btnDisplayStockInfo?.setOnClickListener {
            displayStockInfo()
        }
    }

    private fun insertCompanyStocks() {
        val fieldValues: Array<Array<Any>> = arrayOf(
            arrayOf("Apple", 135.0, 140.0),
            arrayOf("Google", 2000.0, 2020.0),
            arrayOf("Microsoft", 250.0, 255.0)
        )

        try {
            for (values in fieldValues) {
                val companyStock = CompanyStock(values[0] as String, values[1] as Double, values[2] as Double)
                stockManager?.addCompanyStock(companyStock)
            }
            Toast.makeText(this, "Company stocks added successfully.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, e.message, Toast.LENGTH_SHORT).show()
            Log.e("Error: ", e.message.toString())
        }
    }

    private fun handleRadioGroupChanges(checkedId: Int) {
        selectedCompanyName = when (checkedId) {
            R.id.apple_radio_btn -> "Apple"
            R.id.google_radio_btn -> "Google"
            R.id.microsoft_radio_btn -> "Microsoft"
            else -> null
        }
    }

    @SuppressLint("SetTextI18n")
    private fun displayStockInfo() {
        selectedCompanyName?.let { companyName ->
            val cursor = stockManager?.getCompanyStock(companyName)
            if (cursor?.moveToFirst() == true) {
                companyNameTextView?.text = "Company Name: ${cursor.getString(0)}"
                openingPriceTextView?.text = "Opening Price: ${cursor.getDouble(1)}"
                closingPriceTextView?.text = "Closing Price: ${cursor.getDouble(2)}"
                cursor.close()

                companyNameTextView?.visibility = View.VISIBLE
                openingPriceTextView?.visibility = View.VISIBLE
                closingPriceTextView?.visibility = View.VISIBLE
            } else {
                Toast.makeText(this, "No data found for $companyName", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
