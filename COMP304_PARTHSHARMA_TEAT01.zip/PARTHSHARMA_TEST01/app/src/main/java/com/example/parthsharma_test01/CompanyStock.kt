package com.example.parthsharma_test01

import android.os.Parcel
import android.os.Parcelable

/**
 * Kotlin class for CompanyStock.
 */
class CompanyStock(
    var companyName: String?,
    var openingPrice: Double,
    var closingPrice: Double
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readDouble(),
        parcel.readDouble()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(companyName)
        parcel.writeDouble(openingPrice)
        parcel.writeDouble(closingPrice)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<CompanyStock> {
        override fun createFromParcel(parcel: Parcel): CompanyStock {
            return CompanyStock(parcel)
        }

        override fun newArray(size: Int): Array<CompanyStock?> {
            return arrayOfNulls(size)
        }
    }
}
