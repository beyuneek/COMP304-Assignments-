package com.example.group2_comp304lab1_ex2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

private const val TAG = "MainActivity"

class MainActivity : AppCompatActivity() {
    private var bottomFragment: BottomFragment? = null

    public fun sendMessage(messageID: String, message: String) {
        bottomFragment?.setText(messageID, message)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bottomFragment = supportFragmentManager?.findFragmentById(R.id.fragmentContainerViewBottom) as BottomFragment?
        sendMessage("$TAG.onCreate", "onCreate of $TAG Executed")
    }

    /*
    override fun onStart() {
        super.onStart()
        sendMessage("$TAG.onStart", "onStart of $TAG Executed")
    }

    override fun onStop() {
        super.onStop()
        sendMessage("$TAG.onStop", "onStop of $TAG Executed")
    }

    override fun onDestroy() {
        super.onDestroy()
        sendMessage("$TAG.onDestroy", "onDestroy of $TAG Executed")
    }
    */

}