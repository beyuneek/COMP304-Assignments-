package com.example.parth_sharma_midterm

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Activity2 : AppCompatActivity() {

    private var selectedExercise: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_brain_challenge)
        setTitle(resources.getString(R.string.header))

        val exercisesRadioGroup = findViewById<RadioGroup>(R.id.exercisesRadioGroup)
        val exercise1RadioButton = findViewById<RadioButton>(R.id.exercise1RadioButton)
        val exercise2RadioButton = findViewById<RadioButton>(R.id.exercise2RadioButton)
        val exercise3RadioButton = findViewById<RadioButton>(R.id.exercise3RadioButton)
        val exercise4RadioButton = findViewById<RadioButton>(R.id.exercise4RadioButton)

        exercisesRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedExercise = when (checkedId) {
                R.id.exercise1RadioButton -> exercise1RadioButton.text.toString()
                R.id.exercise2RadioButton -> exercise2RadioButton.text.toString()
                R.id.exercise3RadioButton -> exercise3RadioButton.text.toString()
                R.id.exercise4RadioButton -> exercise4RadioButton.text.toString()
                else -> null
            }
        }

        val nextButton = findViewById<Button>(R.id.nextButton)
        nextButton.setOnClickListener {
            selectedExercise?.let {
                Toast.makeText(this, it, Toast.LENGTH_SHORT).show()
            } ?: run {
                Toast.makeText(this, "No exercise selected", Toast.LENGTH_SHORT).show()
            }
        }

        val zigzagImageView = findViewById<ImageView>(R.id.zigzagImageView)
        drawZigzagLine(zigzagImageView)
    }

    private fun drawZigzagLine(zigzagImageView: ImageView) {
        val memoryCycle = resources.getStringArray(R.array.memoryCycleArray)

        var x = 0
        var y: Int
        val paint = Paint()

        paint.color = Color.WHITE
        paint.strokeWidth = 5f

        val width = resources.getDimension(R.dimen.img_width).toInt()
        val height = resources.getDimension(R.dimen.img_height).toInt()

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        var flip = true

        for (yCoordinateString in memoryCycle) {
            y = yCoordinateString.toInt()
            canvas.drawLine(
                x.toFloat(),
                y.toFloat(),
                x.toFloat() + 100,
                (if (flip) y - 30 else y + 30).toFloat(),
                paint
            )
            x += 100
            flip = !flip
        }

        zigzagImageView.setImageBitmap(bitmap)
    }

    override fun onDestroy() {
        super.onDestroy()
        println("Brain Activity Destroyed")
    }
}
