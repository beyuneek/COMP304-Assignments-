package com.example.parth_sharma_midterm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.parth_sharma_midterm.databinding.ActivityMainBinding
/*
Name- Parth Sharmma
Student ID - 301250690
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.startChallengeButton.setOnClickListener {
            val intent = Intent(this, Activity2::class.java)
            startActivity(intent);
        }

    }

    override fun onDestroy() {
        println("Main Activity Destroyed")
        super.onDestroy()
    }
}