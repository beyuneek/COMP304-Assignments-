package com.example.group2_comp304lab2_ex1

data class HomeRecyclerViewData(
    val address: String,
    val price: Float,
    var isChecked: Boolean,
    val image_path: String
)

