package com.example.group2_comp304lab2_ex1

import android.os.Bundle


class HomeTypes : HomeTypeMenu() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_types)
    }

}