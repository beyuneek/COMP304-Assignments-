package com.example.group2_comp304lab6

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// class for storing the programs and courses
data class Program(val name: String, val courses: List<Course>)
data class Course(val name: String, val description: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {

                // define a list of programs and the corresponding courses
                val programs = listOf(
                    Program(
                        name = "Software Engineering Technician",
                        courses = listOf(
                            Course(
                                name = "Data Structures and Algorithms",
                                description = "This course covers the design and analysis of algorithms, data structures, and their applications."
                            ),
                            Course(
                                name = "Software Testing and Quality Assurance",
                                description = "This course covers the concepts and techniques of software testing and quality assurance, including testing strategies, test automation, and quality metrics."
                            ),
                            Course(
                                name = "Networking for Software Developers",
                                description = "Learners in this course will gain hands-on experience by applying knowledge of network protocols and components to the development and maintenance of software applications. Coursework emphasizes network stacks, socket-based network applications."
                            ),
                            Course(
                                name = "Programming 3",
                                description = "The goal of this course is to enable students, already proficient in OOP, to build robust and more complex, data-driven desktop applications using the .NET technologies. Coursework emphasizes advanced topics, such as generics, extension methods."
                            ),
                            Course(
                                name = "Mobile Apps Development ",
                                description = "In this mobile apps course, students will gain hands-on experience in developing and deploying mobile applications on the Android platform. Coursework emphasizes how to create advanced Graphical User Interfaces (GUIs), handle events, access remote services, store and retrieve data on the device, display maps, and use other Android APIs. Android Studio will be used to create a variety of mobile applications."
                            ),
                            Course(
                                name = "Linear Algebra and Statistics",
                                description = "This course contains topics in Linear Algebra and Statistics. Linear algebra topics include operations with matrices, inverses, determinants, and vectors. Statistics topics include descriptive statistics, probability distributions as well as inferential statistics including hypothesis testing. Students will also use software applications in solving relevant problems."
                            ),
                        )
                    ),
                    Program(
                        name = "Health Informatics Technology",
                        courses = listOf(
                            Course(
                                name = "IT Project Management",
                                description = "Students are taught the concepts and basic functions of Project Management, and the integration of these concepts and functions into a coherent project management system. Also, role of the project manager and the project management team in implementing and controlling projects. Further, the Project Management Body of Knowledge PMBOK® as defined by the Project Management Institute PMI and its application to Project Management. CNET307 may be delivered in on-line mode."
                            ),
                            Course(
                                name = "Networking for Software Developers",
                                description = "Learners in this course will gain hands-on experience by applying knowledge of network protocols and components to the development and maintenance of software applications. Coursework emphasizes network stacks, socket-based network applications, software-defined networks, and developing client applications that interface with various intelligent devices."
                            ),
                            Course(
                                name = "Enterprise Systems Integration",
                                description = "This course is about Enterprise Systems Integration"
                            ),
                            Course(
                                name = "Programming 3",
                                description = "The goal of this course is to enable students, already proficient in OOP, to build robust and more complex, data-driven desktop applications using the .NET technologies. Coursework emphasizes advanced topics, such as generics, extension methods."
                            ),
                            Course(
                                name = "Mobile Apps Development ",
                                description = "In this mobile apps course, students will gain hands-on experience in developing and deploying mobile applications on the Android platform. Coursework emphasizes how to create advanced Graphical User Interfaces (GUIs), handle events, access remote services, store and retrieve data on the device, display maps, and use other Android APIs. Android Studio will be used to create a variety of mobile applications."
                            ),
                            Course(
                                name = "Linear Algebra and Statistics",
                                description = "This course contains topics in Linear Algebra and Statistics. Linear algebra topics include operations with matrices, inverses, determinants, and vectors. Statistics topics include descriptive statistics, probability distributions as well as inferential statistics including hypothesis testing. Students will also use software applications in solving relevant problems."
                            ),
                        )
                    ),

                    Program(
                        name = "Software Engineering Technology",
                        courses = listOf(
                            Course(
                                name = "IT Project Management",
                                description = "Students are taught the concepts and basic functions of Project Management, and the integration of these concepts and functions into a coherent project management system. Also, role of the project manager and the project management team in implementing and controlling projects. Further, the Project Management Body of Knowledge PMBOK® as defined by the Project Management Institute PMI and its application to Project Management. CNET307 may be delivered in on-line mode."
                            ),
                            Course(
                                name = "Networking for Software Developers",
                                description = "Learners in this course will gain hands-on experience by applying knowledge of network protocols and components to the development and maintenance of software applications. Coursework emphasizes network stacks, socket-based network applications, software-defined networks, and developing client applications that interface with various intelligent devices."
                            ),
                            Course(
                                name = "Enterprise Systems Integration",
                                description = "This course is about Enterprise Systems Integration"
                            ),
                            Course(
                                name = "Programming 3",
                                description = "The goal of this course is to enable students, already proficient in OOP, to build robust and more complex, data-driven desktop applications using the .NET technologies. Coursework emphasizes advanced topics, such as generics, extension methods."
                            ),
                            Course(
                                name = "Mobile Apps Development ",
                                description = "In this mobile apps course, students will gain hands-on experience in developing and deploying mobile applications on the Android platform. Coursework emphasizes how to create advanced Graphical User Interfaces (GUIs), handle events, access remote services, store and retrieve data on the device, display maps, and use other Android APIs. Android Studio will be used to create a variety of mobile applications."
                            ),
                            Course(
                                name = "Linear Algebra and Statistics",
                                description = "This course contains topics in Linear Algebra and Statistics. Linear algebra topics include operations with matrices, inverses, determinants, and vectors. Statistics topics include descriptive statistics, probability distributions as well as inferential statistics including hypothesis testing. Students will also use software applications in solving relevant problems."
                            ),
                        )
                    ),
                    Program(
                        name = "Artificial Intelligence",
                        courses = listOf(
                            Course(
                                name = "AI Ethics and Data Governance",
                                description = "This course is about AI Ethics and Data Governance"
                            ), Course(
                                name = "Natural Language Processing and Recommender Systems",
                                description = "This course is about Natural Language Processing and Recommender Systems"
                            ), Course(
                                name = "Deep Learning",
                                description = "This course is about Deep Learning"
                            ), Course(
                                name = "Cloud Machine Learning",
                                description = "This course is about Cloud Machine Learning"
                            ), Course(
                                name = "Software Development Project 2",
                                description = "This course is about Software Development Project 2"
                            ), Course(
                                name = "Employment Skills 2",
                                description = "This course is about Employment Skills 2"
                            ), Course(
                                name = "General Education Elective",
                                description = "This course is about General Education Elective"
                            )
                        )
                    ),
                    Program(
                        name = "Game – Programming",
                        courses = listOf(

                        )
                    ),
                    Program(
                        name = "Computer Systems Technician - Networking",
                        courses = listOf(

                        )
                    )
                )

                MainScreen(programs)

            }
        }
    }
}

@Composable
fun CourseItem(course: Course, onClick: (Course) -> Unit, onItemClick: (Course) -> Unit) {
    Card(
        modifier = Modifier
            .padding(vertical = 8.dp)
            .fillMaxWidth()
            .clickable { onClick(course) }
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = course.name,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
            Text(
                text = course.description,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onItemClick(course) }
            )
        }
    }
}

@Composable
fun MainScreen(programs: List<Program>) {
    var selectedProgram by remember { mutableStateOf<Program?>(null) }
    var selectedCourse by remember { mutableStateOf<Course?>(null) }
    var expanded by remember { mutableStateOf(true) }

    Scaffold(   // layout
        topBar = {
            TopAppBar(  // title bar
                title = {
                    Text(
                        text = "SEM4 Courses"
                    )
                },
                backgroundColor = MaterialTheme.colors.onPrimary
            )
        }
    ) {

        Column(modifier = Modifier.padding(16.dp)) {    // layout
            // Dropdown menu to select program
            // by default it is expanded
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { selectedProgram = null },
                modifier = Modifier.fillMaxWidth()
            ) {
                programs.forEach { program ->
                    DropdownMenuItem(
                        onClick = {
                            expanded= false
                            selectedProgram = program
                            selectedCourse = null
                        }
                    ) {
                        Text(text = program.name)
                    }
                }
            }

            // List of courses for selected program
            if (!expanded && selectedProgram != null) {
                ClickableText(
                    text = AnnotatedString("SEM4 Courses for ${selectedProgram!!.name}"),
                    style = MaterialTheme.typography.h5,
                    modifier = Modifier.padding(vertical = 16.dp),
                    onClick = {
                        expanded= true
                    }
                )
                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                    items(selectedProgram!!.courses) { course ->
                        CourseItem(course = course,
                            onClick = {},
                            onItemClick = {})
                    }
                }
            }

        }
    }
}



